<?php include "Templates/gestionarPuertas.html"?>

<div class="container">
        <table class="table table-hover table-wrapper-scroll-y">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Zona</th>
                <th scope="col">Descripcion</th>
                <th scope="col">Grupo</th>
                <th></th>
              </tr>
            </thead>
            <tbody>

<!--Muestra registros para Puertas-->
<?php 
    $enlace = mysqli_connect("localhost", "root", "", "accesosbd");

    if (!$enlace) {
        echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
        echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
        exit;
    }

    $query = "SELECT * FROM puerta";

    if ($result = $enlace->query($query)){
        while($r = $result->fetch_assoc()){
            $id = $r['ID'];
            $zona = $r['Zona'];
            $descripcion = $r['Descripcion'];
            $grupo = $r['FKIdGrupoPuerta'];

            echo '<tr>';
            echo '<th scope="row">',$id,'</th>';
            echo '<td>',$zona,'</td>';
            echo '<td>',$descripcion,'</td>';
            echo '<td>',$grupo,'</td>';
            echo '<td>';
            echo "<form action='gPuerta.php' method='delete'>";
            echo "<input type='hidden' name='id' value='",$r['ID'],"'>";
            echo "<input class='btn btn-danger ms-3' type='submit' name='delete' value='Eliminar'>";
            echo "</form>";
            echo'</td>';
            echo '<td>';
            echo "<form action='gPuerta.php' method='put'>";
            echo "<input type='hidden' name='id' value='",$r['ID'],"'>";
            echo "<input class='btn btn-secondary' type='submit' name='update' value='Modificar'>";
            echo "</form>";
            echo'</td>';
            echo '</tr>';
        }//fin while filas
    }
    mysqli_close($enlace);
?>
            </tbody>
        </table>
    </div>

    <div class="container text-center">
      <a  href="formPuerta.php" id="BtnPersonaAnadir" class="btn btn-primary">Añadir<a/>
    </div>


<!--Borrar puerta-->
<?php
  $enlace = mysqli_connect("localhost", "root", "", "accesosbd");

  if (!$enlace) {
      echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
      echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
      exit;
  }

  if (isset($_GET['delete'])) {
      $id = $_GET['id'];
      $sql = "DELETE FROM puerta WHERE id = $id";

      if (!$resultado = $enlace->query($sql)) {
          echo "Lo sentimos, este sitio web está experimentando problemas.";
          exit;
      }

      echo "<script>window.location.href = 'gPuerta.php';</script>";
  }

  mysqli_close($enlace);

?>
