﻿
namespace RECTANGULO_TRIANGULO_AREA
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Baser = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Altur = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.base_rectangulo = new System.Windows.Forms.Label();
            this.area_rectangulo = new System.Windows.Forms.Label();
            this.altura_rectangulo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Baset = new System.Windows.Forms.TextBox();
            this.Altut = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.base_triangulo = new System.Windows.Forms.Label();
            this.altura_triangulo = new System.Windows.Forms.Label();
            this.area_triangulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.HotPink;
            this.label1.Location = new System.Drawing.Point(124, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "RECTANGULO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label2.Location = new System.Drawing.Point(70, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ingrese la base";
            // 
            // Baser
            // 
            this.Baser.Location = new System.Drawing.Point(326, 191);
            this.Baser.Name = "Baser";
            this.Baser.Size = new System.Drawing.Size(147, 22);
            this.Baser.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label3.Location = new System.Drawing.Point(70, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(233, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ingrese la altura";
            // 
            // Altur
            // 
            this.Altur.Location = new System.Drawing.Point(326, 254);
            this.Altur.Name = "Altur";
            this.Altur.Size = new System.Drawing.Size(147, 22);
            this.Altur.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Crimson;
            this.button1.Location = new System.Drawing.Point(56, 338);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(202, 53);
            this.button1.TabIndex = 5;
            this.button1.Text = "LIMPIAR\r\n";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Crimson;
            this.button2.Location = new System.Drawing.Point(296, 338);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(202, 53);
            this.button2.TabIndex = 6;
            this.button2.Text = "Calcular\r\n";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // base_rectangulo
            // 
            this.base_rectangulo.AutoSize = true;
            this.base_rectangulo.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.base_rectangulo.Location = new System.Drawing.Point(93, 445);
            this.base_rectangulo.Name = "base_rectangulo";
            this.base_rectangulo.Size = new System.Drawing.Size(0, 23);
            this.base_rectangulo.TabIndex = 7;
            // 
            // area_rectangulo
            // 
            this.area_rectangulo.AutoSize = true;
            this.area_rectangulo.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.area_rectangulo.Location = new System.Drawing.Point(93, 539);
            this.area_rectangulo.Name = "area_rectangulo";
            this.area_rectangulo.Size = new System.Drawing.Size(0, 23);
            this.area_rectangulo.TabIndex = 8;
            // 
            // altura_rectangulo
            // 
            this.altura_rectangulo.AutoSize = true;
            this.altura_rectangulo.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.altura_rectangulo.Location = new System.Drawing.Point(93, 488);
            this.altura_rectangulo.Name = "altura_rectangulo";
            this.altura_rectangulo.Size = new System.Drawing.Size(0, 23);
            this.altura_rectangulo.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Cooper Black", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.HotPink;
            this.label4.Location = new System.Drawing.Point(848, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(234, 38);
            this.label4.TabIndex = 10;
            this.label4.Text = "TRIANGULO\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label5.Location = new System.Drawing.Point(750, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(207, 28);
            this.label5.TabIndex = 11;
            this.label5.Text = "Ingrese la base";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label6.Location = new System.Drawing.Point(750, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(233, 28);
            this.label6.TabIndex = 12;
            this.label6.Text = "Ingrese la altura";
            // 
            // Baset
            // 
            this.Baset.Location = new System.Drawing.Point(1004, 190);
            this.Baset.Name = "Baset";
            this.Baset.Size = new System.Drawing.Size(147, 22);
            this.Baset.TabIndex = 13;
            // 
            // Altut
            // 
            this.Altut.Location = new System.Drawing.Point(1013, 250);
            this.Altut.Name = "Altut";
            this.Altut.Size = new System.Drawing.Size(147, 22);
            this.Altut.TabIndex = 14;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Crimson;
            this.button3.Location = new System.Drawing.Point(755, 326);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(202, 53);
            this.button3.TabIndex = 15;
            this.button3.Text = "LIMPIAR\r\n";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Crimson;
            this.button4.Location = new System.Drawing.Point(984, 326);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(202, 53);
            this.button4.TabIndex = 16;
            this.button4.Text = "Calcular\r\n";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // base_triangulo
            // 
            this.base_triangulo.AutoSize = true;
            this.base_triangulo.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.base_triangulo.Location = new System.Drawing.Point(770, 445);
            this.base_triangulo.Name = "base_triangulo";
            this.base_triangulo.Size = new System.Drawing.Size(0, 23);
            this.base_triangulo.TabIndex = 17;
            // 
            // altura_triangulo
            // 
            this.altura_triangulo.AutoSize = true;
            this.altura_triangulo.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.altura_triangulo.Location = new System.Drawing.Point(770, 488);
            this.altura_triangulo.Name = "altura_triangulo";
            this.altura_triangulo.Size = new System.Drawing.Size(0, 23);
            this.altura_triangulo.TabIndex = 18;
            // 
            // area_triangulo
            // 
            this.area_triangulo.AutoSize = true;
            this.area_triangulo.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.area_triangulo.Location = new System.Drawing.Point(770, 539);
            this.area_triangulo.Name = "area_triangulo";
            this.area_triangulo.Size = new System.Drawing.Size(0, 23);
            this.area_triangulo.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1221, 730);
            this.Controls.Add(this.area_triangulo);
            this.Controls.Add(this.altura_triangulo);
            this.Controls.Add(this.base_triangulo);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Altut);
            this.Controls.Add(this.Baset);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.altura_rectangulo);
            this.Controls.Add(this.area_rectangulo);
            this.Controls.Add(this.base_rectangulo);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Altur);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Baser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Baser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Altur;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label base_rectangulo;
        private System.Windows.Forms.Label area_rectangulo;
        private System.Windows.Forms.Label altura_rectangulo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Baset;
        private System.Windows.Forms.TextBox Altut;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label base_triangulo;
        private System.Windows.Forms.Label altura_triangulo;
        private System.Windows.Forms.Label area_triangulo;
    }
}

