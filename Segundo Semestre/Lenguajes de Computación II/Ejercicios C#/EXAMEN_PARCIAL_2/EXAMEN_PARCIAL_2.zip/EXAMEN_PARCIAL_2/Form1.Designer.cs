﻿
namespace EXAMEN_PARCIAL_2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Resu = new System.Windows.Forms.TextBox();
            this.cero = new System.Windows.Forms.Button();
            this.uno = new System.Windows.Forms.Button();
            this.dos = new System.Windows.Forms.Button();
            this.tres = new System.Windows.Forms.Button();
            this.cuatro = new System.Windows.Forms.Button();
            this.cinco = new System.Windows.Forms.Button();
            this.seis = new System.Windows.Forms.Button();
            this.siete = new System.Windows.Forms.Button();
            this.ocho = new System.Windows.Forms.Button();
            this.nueve = new System.Windows.Forms.Button();
            this.punto = new System.Windows.Forms.Button();
            this.igual = new System.Windows.Forms.Button();
            this.factorial = new System.Windows.Forms.Button();
            this.limpiarResu = new System.Windows.Forms.Button();
            this.borrarValor = new System.Windows.Forms.Button();
            this.resta = new System.Windows.Forms.Button();
            this.division = new System.Windows.Forms.Button();
            this.multiplicacion = new System.Windows.Forms.Button();
            this.suma = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.NumIngre = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Resu
            // 
            this.Resu.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Resu.Font = new System.Drawing.Font("DS-Digital", 55.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resu.ForeColor = System.Drawing.Color.Black;
            this.Resu.Location = new System.Drawing.Point(66, 70);
            this.Resu.Name = "Resu";
            this.Resu.Size = new System.Drawing.Size(421, 99);
            this.Resu.TabIndex = 0;
            // 
            // cero
            // 
            this.cero.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cero.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cero.Location = new System.Drawing.Point(51, 645);
            this.cero.Name = "cero";
            this.cero.Size = new System.Drawing.Size(96, 59);
            this.cero.TabIndex = 1;
            this.cero.Text = "0";
            this.cero.UseVisualStyleBackColor = false;
            this.cero.Click += new System.EventHandler(this.cero_Click);
            // 
            // uno
            // 
            this.uno.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.uno.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uno.Location = new System.Drawing.Point(51, 571);
            this.uno.Name = "uno";
            this.uno.Size = new System.Drawing.Size(96, 59);
            this.uno.TabIndex = 2;
            this.uno.Text = "1";
            this.uno.UseVisualStyleBackColor = false;
            this.uno.Click += new System.EventHandler(this.uno_Click);
            // 
            // dos
            // 
            this.dos.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dos.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dos.Location = new System.Drawing.Point(169, 571);
            this.dos.Name = "dos";
            this.dos.Size = new System.Drawing.Size(96, 59);
            this.dos.TabIndex = 3;
            this.dos.Text = "2";
            this.dos.UseVisualStyleBackColor = false;
            this.dos.Click += new System.EventHandler(this.dos_Click);
            // 
            // tres
            // 
            this.tres.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tres.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tres.Location = new System.Drawing.Point(285, 571);
            this.tres.Name = "tres";
            this.tres.Size = new System.Drawing.Size(96, 59);
            this.tres.TabIndex = 4;
            this.tres.Text = "3";
            this.tres.UseVisualStyleBackColor = false;
            this.tres.Click += new System.EventHandler(this.tres_Click);
            // 
            // cuatro
            // 
            this.cuatro.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cuatro.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cuatro.Location = new System.Drawing.Point(51, 494);
            this.cuatro.Name = "cuatro";
            this.cuatro.Size = new System.Drawing.Size(96, 59);
            this.cuatro.TabIndex = 5;
            this.cuatro.Text = "4";
            this.cuatro.UseVisualStyleBackColor = false;
            this.cuatro.Click += new System.EventHandler(this.cuatro_Click);
            // 
            // cinco
            // 
            this.cinco.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cinco.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cinco.Location = new System.Drawing.Point(169, 494);
            this.cinco.Name = "cinco";
            this.cinco.Size = new System.Drawing.Size(96, 59);
            this.cinco.TabIndex = 6;
            this.cinco.Text = "5";
            this.cinco.UseVisualStyleBackColor = false;
            this.cinco.Click += new System.EventHandler(this.cinco_Click);
            // 
            // seis
            // 
            this.seis.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.seis.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seis.Location = new System.Drawing.Point(285, 494);
            this.seis.Name = "seis";
            this.seis.Size = new System.Drawing.Size(96, 59);
            this.seis.TabIndex = 7;
            this.seis.Text = "6";
            this.seis.UseVisualStyleBackColor = false;
            this.seis.Click += new System.EventHandler(this.seis_Click);
            // 
            // siete
            // 
            this.siete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.siete.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siete.Location = new System.Drawing.Point(51, 420);
            this.siete.Name = "siete";
            this.siete.Size = new System.Drawing.Size(96, 59);
            this.siete.TabIndex = 8;
            this.siete.Text = "7";
            this.siete.UseVisualStyleBackColor = false;
            this.siete.Click += new System.EventHandler(this.siete_Click);
            // 
            // ocho
            // 
            this.ocho.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ocho.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ocho.Location = new System.Drawing.Point(169, 420);
            this.ocho.Name = "ocho";
            this.ocho.Size = new System.Drawing.Size(96, 59);
            this.ocho.TabIndex = 9;
            this.ocho.Text = "8";
            this.ocho.UseVisualStyleBackColor = false;
            this.ocho.Click += new System.EventHandler(this.ocho_Click);
            // 
            // nueve
            // 
            this.nueve.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.nueve.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nueve.Location = new System.Drawing.Point(285, 420);
            this.nueve.Name = "nueve";
            this.nueve.Size = new System.Drawing.Size(96, 59);
            this.nueve.TabIndex = 10;
            this.nueve.Text = "9";
            this.nueve.UseVisualStyleBackColor = false;
            this.nueve.Click += new System.EventHandler(this.nueve_Click);
            // 
            // punto
            // 
            this.punto.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.punto.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.punto.Location = new System.Drawing.Point(169, 645);
            this.punto.Name = "punto";
            this.punto.Size = new System.Drawing.Size(96, 59);
            this.punto.TabIndex = 11;
            this.punto.Text = ".";
            this.punto.UseVisualStyleBackColor = false;
            this.punto.Click += new System.EventHandler(this.button11_Click);
            // 
            // igual
            // 
            this.igual.BackColor = System.Drawing.Color.IndianRed;
            this.igual.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.igual.Location = new System.Drawing.Point(400, 571);
            this.igual.Name = "igual";
            this.igual.Size = new System.Drawing.Size(96, 133);
            this.igual.TabIndex = 12;
            this.igual.Text = "=";
            this.igual.UseVisualStyleBackColor = false;
            this.igual.Click += new System.EventHandler(this.igual_Click);
            // 
            // factorial
            // 
            this.factorial.BackColor = System.Drawing.Color.IndianRed;
            this.factorial.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.factorial.Location = new System.Drawing.Point(285, 645);
            this.factorial.Name = "factorial";
            this.factorial.Size = new System.Drawing.Size(96, 59);
            this.factorial.TabIndex = 13;
            this.factorial.Text = "X!";
            this.factorial.UseVisualStyleBackColor = false;
            this.factorial.Click += new System.EventHandler(this.factorial_Click);
            // 
            // limpiarResu
            // 
            this.limpiarResu.BackColor = System.Drawing.Color.IndianRed;
            this.limpiarResu.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpiarResu.Location = new System.Drawing.Point(400, 269);
            this.limpiarResu.Name = "limpiarResu";
            this.limpiarResu.Size = new System.Drawing.Size(96, 59);
            this.limpiarResu.TabIndex = 14;
            this.limpiarResu.Text = "CE";
            this.limpiarResu.UseVisualStyleBackColor = false;
            this.limpiarResu.Click += new System.EventHandler(this.limpiarResu_Click);
            // 
            // borrarValor
            // 
            this.borrarValor.BackColor = System.Drawing.Color.IndianRed;
            this.borrarValor.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrarValor.Location = new System.Drawing.Point(285, 269);
            this.borrarValor.Name = "borrarValor";
            this.borrarValor.Size = new System.Drawing.Size(96, 59);
            this.borrarValor.TabIndex = 15;
            this.borrarValor.Text = "C";
            this.borrarValor.UseVisualStyleBackColor = false;
            this.borrarValor.Click += new System.EventHandler(this.borrarValor_Click);
            // 
            // resta
            // 
            this.resta.BackColor = System.Drawing.Color.IndianRed;
            this.resta.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resta.Location = new System.Drawing.Point(51, 269);
            this.resta.Name = "resta";
            this.resta.Size = new System.Drawing.Size(96, 59);
            this.resta.TabIndex = 17;
            this.resta.Text = "-";
            this.resta.UseVisualStyleBackColor = false;
            this.resta.Click += new System.EventHandler(this.resta_Click);
            // 
            // division
            // 
            this.division.BackColor = System.Drawing.Color.IndianRed;
            this.division.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.division.Location = new System.Drawing.Point(169, 269);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(96, 59);
            this.division.TabIndex = 16;
            this.division.Text = "/";
            this.division.UseVisualStyleBackColor = false;
            this.division.Click += new System.EventHandler(this.division_Click);
            // 
            // multiplicacion
            // 
            this.multiplicacion.BackColor = System.Drawing.Color.IndianRed;
            this.multiplicacion.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiplicacion.Location = new System.Drawing.Point(51, 345);
            this.multiplicacion.Name = "multiplicacion";
            this.multiplicacion.Size = new System.Drawing.Size(96, 59);
            this.multiplicacion.TabIndex = 18;
            this.multiplicacion.Text = "X";
            this.multiplicacion.UseVisualStyleBackColor = false;
            this.multiplicacion.Click += new System.EventHandler(this.multiplicacion_Click);
            // 
            // suma
            // 
            this.suma.BackColor = System.Drawing.Color.IndianRed;
            this.suma.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suma.Location = new System.Drawing.Point(169, 345);
            this.suma.Name = "suma";
            this.suma.Size = new System.Drawing.Size(96, 59);
            this.suma.TabIndex = 19;
            this.suma.Text = "+";
            this.suma.UseVisualStyleBackColor = false;
            this.suma.Click += new System.EventHandler(this.suma_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.IndianRed;
            this.button20.Font = new System.Drawing.Font("Verdana", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(285, 345);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(96, 59);
            this.button20.TabIndex = 20;
            this.button20.Text = "%";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // NumIngre
            // 
            this.NumIngre.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.NumIngre.Font = new System.Drawing.Font("DS-Digital", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumIngre.ForeColor = System.Drawing.Color.Black;
            this.NumIngre.Location = new System.Drawing.Point(329, 215);
            this.NumIngre.Name = "NumIngre";
            this.NumIngre.Size = new System.Drawing.Size(158, 27);
            this.NumIngre.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.IndianRed;
            this.button1.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(398, 420);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 133);
            this.button1.TabIndex = 22;
            this.button1.Text = "SUMA I-N";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.IndianRed;
            this.button2.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(398, 343);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 60);
            this.button2.TabIndex = 23;
            this.button2.Text = "OFF";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(552, 781);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.NumIngre);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.suma);
            this.Controls.Add(this.multiplicacion);
            this.Controls.Add(this.resta);
            this.Controls.Add(this.division);
            this.Controls.Add(this.borrarValor);
            this.Controls.Add(this.limpiarResu);
            this.Controls.Add(this.factorial);
            this.Controls.Add(this.igual);
            this.Controls.Add(this.punto);
            this.Controls.Add(this.nueve);
            this.Controls.Add(this.ocho);
            this.Controls.Add(this.siete);
            this.Controls.Add(this.seis);
            this.Controls.Add(this.cinco);
            this.Controls.Add(this.cuatro);
            this.Controls.Add(this.tres);
            this.Controls.Add(this.dos);
            this.Controls.Add(this.uno);
            this.Controls.Add(this.cero);
            this.Controls.Add(this.Resu);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Resu;
        private System.Windows.Forms.Button cero;
        private System.Windows.Forms.Button uno;
        private System.Windows.Forms.Button dos;
        private System.Windows.Forms.Button tres;
        private System.Windows.Forms.Button cuatro;
        private System.Windows.Forms.Button cinco;
        private System.Windows.Forms.Button seis;
        private System.Windows.Forms.Button siete;
        private System.Windows.Forms.Button ocho;
        private System.Windows.Forms.Button nueve;
        private System.Windows.Forms.Button punto;
        private System.Windows.Forms.Button igual;
        private System.Windows.Forms.Button factorial;
        private System.Windows.Forms.Button limpiarResu;
        private System.Windows.Forms.Button borrarValor;
        private System.Windows.Forms.Button resta;
        private System.Windows.Forms.Button division;
        private System.Windows.Forms.Button multiplicacion;
        private System.Windows.Forms.Button suma;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox NumIngre;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

