import java.awt.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.image.BufferedImage;



public class FASE_1_ImageChange extends JFrame implements ActionListener{

    
    private JMenuBar menubar;
    private JMenu archivo,operadores;
    private JMenuItem abrir,original,save, gray,negative,binary,claro,obscuro,exit;
    private JLabel image;
    
    //private ImageIcon imageo;
    

    File file;
    FileInputStream entrada;
    FileOutputStream salida;
    JFileChooser fileChooser= new JFileChooser();
    byte[] bytesImg;
    

    public FASE_1_ImageChange(){

        super("IMAGECHANGE");
        Container contents=this.getContentPane();
        contents.setLayout(new FlowLayout());
        
        menubar= new JMenuBar();
        setJMenuBar(menubar);
        
        image= new JLabel(); 
        image.setBounds(10,10,400,400);  
        contents.add(image);

        archivo= new JMenu("Archivo");
        menubar.add(archivo);
        
        operadores=new JMenu("Operadores");
        menubar.add(operadores);



        abrir= new JMenuItem("Abrir foto");
        abrir.addActionListener(this);
        archivo.add(abrir);

        original=new JMenuItem("Regresar a Original");
        original.addActionListener(this);
        archivo.add(original);

        save=new JMenuItem("Guardar foto");
        save.addActionListener(this);
        archivo.add(save);

        exit=new JMenuItem("Salir");
        exit.addActionListener(this);
        archivo.add(exit);

        gray=new JMenuItem("Escala de Grises");
        gray.addActionListener(this);
        operadores.add(gray);
        negative= new JMenuItem("Negativo");
        negative.addActionListener(this);
        operadores.add(negative);
        binary= new JMenuItem("Binarizacion");
        binary.addActionListener(this);
        operadores.add(binary);
        claro=new JMenuItem("Más brillo");
        claro.addActionListener(this);
        operadores.add(claro);
        obscuro=new JMenuItem("Menos brillo");
        obscuro.addActionListener(this);
        operadores.add(obscuro);


        setSize(1000,1000);
        setVisible(true);



    }
    public byte[] AbrirImagen(File archivo) {
        byte[] bytesImg = new byte[1000000];
        try {
            entrada = new FileInputStream(archivo);
            entrada.read(bytesImg);
        } catch (Exception e) {
        }
        return bytesImg;
    }

   
    private BufferedImage read;

    public void actionPerformed(ActionEvent e){
        
        
        
       
        //FileNameExtensionFilter imgFilter= new FileNameExtensionFilter("*.images", "jpg","png");
        //fileChooser.addChoosableFileFilter(imgFilter);
         //seleccionar el archivo a abrir
            
        if(e.getSource()==abrir){
            if(fileChooser.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
                file = fileChooser.getSelectedFile();
                if(file.canRead()){
                    try {
                        read=ImageIO.read(file);
                    } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                    //String path= file.getAbsolutePath();
                    //imageo= new ImageIcon(path);
                    //image=new JLabel(imageo);
                    bytesImg=AbrirImagen(file);
                    image.setIcon( new ImageIcon(bytesImg));
                    setSize(read.getWidth(),read.getHeight());

                    //image.setIcon(new ImageIcon(path)); //agrega la imagen
                }

                
            }
        }else if(e.getSource()==original){
            image.setIcon(new ImageIcon(bytesImg));
            try {
                read=ImageIO.read(file);
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            setSize(read.getWidth(),read.getHeight());
            

        }else if(e.getSource()==save){
            try {
                //File filesaved=new File("ImageSaved.jpg");
                ImageIO.write(read, "jpg", file);
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }else if(e.getSource()==exit)
        {
            dispose();
        }
        else if(e.getSource()==gray){

           
            
            for(int i=0;i<read.getWidth();i++){
                for(int j=0;j<read.getHeight();j++){
                    Color color= new Color(read.getRGB(i, j));
                    int rc=color.getRed();
                    int gc=color.getGreen();
                    int bc=color.getBlue();
                    int bw= (rc+gc+bc) / 3;
                    color=new Color(bw,bw,bw);
                    read.setRGB(i,j,color.getRGB());
                }
            }
            
            ImageIcon icon= new ImageIcon(read);
            image.setIcon(icon);

            
        }else if(e.getSource()==negative){

            
                
            for(int x=0;x<read.getWidth();x++){
                for(int y=0;y<read.getHeight();y++){

                    Color color= new Color(read.getRGB(x, y));
                    int rc=255 -color.getRed();
                    int gc=255 -color.getGreen();
                    int bc=255- color.getBlue();

                    color=new Color(rc,gc,bc);

                    

                    read.setRGB(x, y, color.getRGB());
                    

                }
            }
            ImageIcon icon= new ImageIcon(read);
            image.setIcon(icon);
            

        }else if(e.getSource()==binary){
            
            
            
                
            for(int x=0;x<read.getWidth();x++){
                for(int y=0;y<read.getHeight();y++){

                    Color color= new Color(read.getRGB(x, y));
                    int rc=color.getRed();
                    int gc=color.getGreen();
                    int bc=color.getBlue();
                    int pr=(rc+gc+bc) /3;
                    if(pr>127){
                        color=new Color(255,255,255);
                    }else{
                        color=new Color(0,0,0);
                    }

                    read.setRGB(x, y, color.getRGB());
                    

                }
            }
            ImageIcon icon= new ImageIcon(read);
            image.setIcon(icon);



        }else if(e.getSource()==claro){
            for(int i=0;i<read.getWidth();i++){
                for(int j=0;j<read.getHeight();j++){
                    Color color= new Color(read.getRGB(i, j));
                    int rc= (int) (255.0 * Math.pow(Double.valueOf(color.getRed())/255,0.9));
                    int gc= (int) (255.0 * Math.pow(Double.valueOf(color.getGreen())/255,0.9));
                    int bc= (int) (255.0 * Math.pow(Double.valueOf(color.getBlue())/255,0.9));
                    color= new Color(rc,gc,bc);
                    read.setRGB(i, j, color.getRGB());
                }
            }
            ImageIcon icon= new ImageIcon(read);
            image.setIcon(icon);
        }else if(e.getSource()==obscuro){
            for(int i=0;i<read.getWidth();i++){
                for(int j=0;j<read.getHeight();j++){
                    Color color= new Color(read.getRGB(i, j));
                    int rc= (int) (255.0 * Math.pow(Double.valueOf(color.getRed())/255,1.1));
                    int gc= (int) (255.0 * Math.pow(Double.valueOf(color.getGreen())/255,1.1));
                    int bc= (int) (255.0 * Math.pow(Double.valueOf(color.getBlue())/255,1.1));
                    color= new Color(rc,gc,bc);
                    read.setRGB(i, j, color.getRGB());
                }
            }
            ImageIcon icon= new ImageIcon(read);
            image.setIcon(icon);
        }
       
        

        

        
        



    }

    public static void main(String args []){
        FASE_1_ImageChange ic = new FASE_1_ImageChange();
        ic.setDefaultCloseOperation(EXIT_ON_CLOSE);


    }


    
}